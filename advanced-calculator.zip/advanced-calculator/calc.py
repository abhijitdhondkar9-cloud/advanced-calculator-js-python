# calc.py - advanced calculator
# Scientific
import math

def r(x):
    return round(x, 10)

scientific = {
    "sin": lambda d: r(math.sin(math.radians(d))),
    "cos": lambda d: r(math.cos(math.radians(d))),
    "tan": lambda d: r(math.tan(math.radians(d))),
    "log": math.log10,
    "ln": lambda x: r(math.log(x)),
    "sqrt": math.sqrt,
    "pow": lambda x, y: x ** y,
    "fact": math.factorial,
}

# Programmer
programmer = {
    "to_bin": lambda n: bin(n)[2:],
    "to_oct": lambda n: oct(n)[2:],
    "to_hex": lambda n: hex(n)[2:].upper(),
    "from_base": lambda s, base: int(s, base),
    "and": lambda a, b: a & b,
    "or": lambda a, b: a | b,
    "xor": lambda a, b: a ^ b,
}

# Unit converter
units = {
    "length": {"m": 1, "km": 1000, "cm": 0.01,
               "mi": 1609.344, "ft": 0.3048},
    "mass": {"kg": 1, "g": 0.001, "lb": 0.45359237},
}

def convert(value, frm, to, kind):
    if kind == "temp":
        c = value if frm == "C" else (value - 32) * 5 / 9
        return r(c if to == "C" else c * 9 / 5 + 32)
    table = units[kind]
    return r(value * table[frm] / table[to])

# Loan EMI
def emi(principal, annual_rate, months):
    i = annual_rate / 12 / 100
    if i == 0:
        return round(principal / months, 2)
    f = (1 + i) ** months
    return round(principal * i * f / (f - 1), 2)

# Statistics
def mean(xs):
    return sum(xs) / len(xs)

def median(xs):
    s, m = sorted(xs), len(xs) // 2
    return s[m] if len(s) % 2 else (s[m - 1] + s[m]) / 2

def stdev(xs):
    mu = mean(xs)
    v = sum((x - mu) ** 2 for x in xs) / (len(xs) - 1)
    return r(math.sqrt(v))

stats = {"mean": mean, "median": median, "stdev": stdev}
