// calc.js - advanced calculator
// Scientific
const toRad = (deg) => deg * Math.PI / 180;
const round = (x) => +x.toFixed(10);

const scientific = {
  sin: (d) => round(Math.sin(toRad(d))),
  cos: (d) => round(Math.cos(toRad(d))),
  tan: (d) => round(Math.tan(toRad(d))),
  log: (x) => Math.log10(x),
  ln: (x) => round(Math.log(x)),
  sqrt: (x) => Math.sqrt(x),
  pow: (x, y) => x ** y,
  fact: (n) => (n <= 1 ? 1 : n * scientific.fact(n - 1)),
};

// Programmer
const programmer = {
  toBin: (n) => n.toString(2),
  toOct: (n) => n.toString(8),
  toHex: (n) => n.toString(16).toUpperCase(),
  fromBase: (s, base) => parseInt(s, base),
  and: (a, b) => a & b,
  or: (a, b) => a | b,
  xor: (a, b) => a ^ b,
};

// Unit converter
const units = {
  length: { m: 1, km: 1000, cm: 0.01, mi: 1609.344, ft: 0.3048 },
  mass: { kg: 1, g: 0.001, lb: 0.45359237 },
};

function convert(value, from, to, kind) {
  if (kind === "temp") {
    const c = from === "C" ? value : (value - 32) * 5 / 9;
    return round(to === "C" ? c : c * 9 / 5 + 32);
  }
  const table = units[kind];
  return round(value * table[from] / table[to]);
}

// Loan EMI
function emi(principal, annualRate, months) {
  const i = annualRate / 12 / 100;
  if (i === 0) return Math.round(principal / months * 100) / 100;
  const f = (1 + i) ** months;
  return Math.round(principal * i * f / (f - 1) * 100) / 100;
}

// Statistics
const stats = {
  mean: (xs) => xs.reduce((a, b) => a + b, 0) / xs.length,
  median(xs) {
    const s = [...xs].sort((a, b) => a - b), m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  },
  stdev(xs) {
    const mu = stats.mean(xs);
    const sq = xs.reduce((a, x) => a + (x - mu) ** 2, 0);
    return round(Math.sqrt(sq / (xs.length - 1)));
  },
};
