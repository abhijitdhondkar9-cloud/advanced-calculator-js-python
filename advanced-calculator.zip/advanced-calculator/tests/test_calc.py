"""Run with: python tests/test_calc.py"""
from pathlib import Path

ns = {}
exec((Path(__file__).resolve().parent.parent / "calc.py").read_text(encoding="utf-8"), ns)
scientific, programmer = ns["scientific"], ns["programmer"]
convert, emi, stats = ns["convert"], ns["emi"], ns["stats"]
data = [4, 8, 15, 16, 23, 42]

checks = [
    ("sin(30)", scientific["sin"](30), 0.5),
    ("log(1000)", scientific["log"](1000), 3),
    ("sqrt(144)", scientific["sqrt"](144), 12),
    ("pow(2, 10)", scientific["pow"](2, 10), 1024),
    ("fact(5)", scientific["fact"](5), 120),
    ("to_bin(42)", programmer["to_bin"](42), "101010"),
    ("to_hex(255)", programmer["to_hex"](255), "FF"),
    ("from_base('1010', 2)", programmer["from_base"]("1010", 2), 10),
    ("xor(12, 10)", programmer["xor"](12, 10), 6),
    ("5 km -> mi", convert(5, "km", "mi", "length"), 3.1068559612),
    ("100 C -> F", convert(100, "C", "F", "temp"), 212),
    ("98.6 F -> C", convert(98.6, "F", "C", "temp"), 37),
    ("10 kg -> lb", convert(10, "kg", "lb", "mass"), 22.0462262185),
    ("EMI 5L, 8.5%, 60m", emi(500000, 8.5, 60), 10258.27),
    ("EMI 25L, 9%, 240m", emi(2500000, 9, 240), 22493.15),
    ("EMI 0%", emi(120000, 0, 12), 10000),
    ("mean", stats["mean"](data), 18),
    ("median", stats["median"](data), 15.5),
    ("stdev", stats["stdev"](data), 13.4907375632),
]

for name, got, want in checks:
    assert got == want, f"{name}: expected {want}, got {got}"
    print(f"ok  {name} = {got}")
print(f"\nAll {len(checks)} Python checks passed.")
