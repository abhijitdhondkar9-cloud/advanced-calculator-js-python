// Run with: node tests/test_calc.js
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const ctx = {};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, "..", "calc.js"), "utf8") +
  "\nthis.api = { scientific, programmer, convert, emi, stats };", ctx);
const { scientific, programmer, convert, emi, stats } = ctx.api;
const data = [4, 8, 15, 16, 23, 42];

const checks = [
  ["sin(30)", scientific.sin(30), 0.5],
  ["log(1000)", scientific.log(1000), 3],
  ["sqrt(144)", scientific.sqrt(144), 12],
  ["pow(2, 10)", scientific.pow(2, 10), 1024],
  ["fact(5)", scientific.fact(5), 120],
  ["toBin(42)", programmer.toBin(42), "101010"],
  ["toHex(255)", programmer.toHex(255), "FF"],
  ["fromBase('1010', 2)", programmer.fromBase("1010", 2), 10],
  ["xor(12, 10)", programmer.xor(12, 10), 6],
  ["5 km -> mi", convert(5, "km", "mi", "length"), 3.1068559612],
  ["100 C -> F", convert(100, "C", "F", "temp"), 212],
  ["98.6 F -> C", convert(98.6, "F", "C", "temp"), 37],
  ["10 kg -> lb", convert(10, "kg", "lb", "mass"), 22.0462262185],
  ["EMI 5L, 8.5%, 60m", emi(500000, 8.5, 60), 10258.27],
  ["EMI 25L, 9%, 240m", emi(2500000, 9, 240), 22493.15],
  ["EMI 0%", emi(120000, 0, 12), 10000],
  ["mean", stats.mean(data), 18],
  ["median", stats.median(data), 15.5],
  ["stdev", stats.stdev(data), 13.4907375632],
];

for (const [name, got, want] of checks) {
  assert.strictEqual(got, want, `${name}: expected ${want}, got ${got}`);
  console.log(`ok  ${name} = ${got}`);
}
console.log(`\nAll ${checks.length} JavaScript checks passed.`);
